
#include <bits/stdc++.h>
using namespace std;

struct Edge {
    string dest;
    int weight;
};

struct Graph {
    unordered_map<string, list<Edge>> adj;

    void init() {
        adj.clear();
    }

    void addEdge(const string& u, const string& v, int w) {
        adj[u].push_back({v, w});
        if (!adj.count(v)) adj[v]; // ensure both nodes exist
    }

    void printGraph() {
        for (const auto& pair : adj) {
            cout << pair.first << " -> ";
            for (const Edge& e : pair.second)
                cout << e.dest << " (" << e.weight << "), ";
            cout << endl;
        }
    }

    void shortestPath(const string& start, const string& end) {
        unordered_map<string, int> dist;
        unordered_map<string, string> parent;
        for (auto& pair : adj) dist[pair.first] = INT_MAX;
        dist[start] = 0;

        priority_queue<pair<int, string>, vector<pair<int, string>>, greater<>> pq;
        pq.push({0, start});

        while (!pq.empty()) {
            auto [d, u] = pq.top(); pq.pop();
            if (u == end) break;
            for (const Edge& e : adj[u]) {
                if (dist[u] + e.weight < dist[e.dest]) {
                    dist[e.dest] = dist[u] + e.weight;
                    parent[e.dest] = u;
                    pq.push({dist[e.dest], e.dest});
                }
            }
        }

        cout << "\nShortest distance from " << start << " to " << end << " is: " << dist[end] << endl;
        vector<string> path;
        for (string v = end; !v.empty(); v = parent[v])
            path.push_back(v);
        reverse(path.begin(), path.end());
        cout << "Path: ";
        for (size_t i = 0; i < path.size(); ++i) {
            cout << path[i];
            if (i + 1 < path.size()) cout << " -> ";
        }
        cout << endl;
    }
};
